**To describe a Reserved Instance listing**

The following ``describe-reserved-instances-listings`` example retrieves information about the specified Reserved Instance listing. ::

    aws ec2 describe-reserved-instances-listings \
        --reserved-instances-listing-id 5ec28771-05ff-4b9b-aa31-9e57dexample

This command produces no output.
